#-----------------------------------------------------------------------------
#
# GrokConfig.cmake - CMake configuration file for external projects.
#
# This file is configured by Grok and used to load Grok's settings for external projects.

####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was GrokConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/aarch64-linux-gnu/cmake/grok-20.2" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# The Grok version number
set(Grok_VERSION_MAJOR "20")
set(Grok_VERSION_MINOR "2")
set(Grok_VERSION_PATCH "3")
set(Grok_VERSION "20.2.3")

# The libraries
set(Grok_LIBRARIES "GROK::grokj2k" "GROK::grokj2kcodec")

# CMake macros directory
set(Grok_CMAKE_DIR "lib/aarch64-linux-gnu/cmake/grok-20.2")

# Configuration options
set(Grok_BUILD_SHARED_LIBS "ON")

# Determine the prefix directory
set(PACKAGE_PREFIX_DIR "/usr")

# Detect install or build tree
get_filename_component(SELF_DIR "${CMAKE_CURRENT_LIST_FILE}" PATH)
if(EXISTS "${SELF_DIR}/GrokTargets.cmake")
    # Install tree
    include("${SELF_DIR}/GrokTargets.cmake")

    # Include directories
    set(Grok_INCLUDE_DIRS "${PACKAGE_PREFIX_DIR}/include/grok-20.2")

elseif(EXISTS "${SELF_DIR}/GrokExports.cmake")
    # Build tree
    include("${SELF_DIR}/GrokExports.cmake")

    # Include directories for build tree
    set(Grok_INCLUDE_DIRS "")

else()
    # Error if neither install nor build tree targets are found
    message(FATAL_ERROR
        "Could not find GrokTargets.cmake (install tree) or GrokExports.cmake (build tree). "
        "Ensure Grok is built and installed correctly.")
endif()

# Backward compatibility variables
set(Grok_FOUND TRUE)


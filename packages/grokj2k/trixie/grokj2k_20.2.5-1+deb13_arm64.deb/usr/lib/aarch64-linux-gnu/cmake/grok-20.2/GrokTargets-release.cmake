#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "GROK::grokj2k" for configuration "Release"
set_property(TARGET GROK::grokj2k APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(GROK::grokj2k PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libgrokj2k.so.20.2.5"
  IMPORTED_SONAME_RELEASE "libgrokj2k.so.1"
  )

list(APPEND _cmake_import_check_targets GROK::grokj2k )
list(APPEND _cmake_import_check_files_for_GROK::grokj2k "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libgrokj2k.so.20.2.5" )

# Import target "GROK::grokj2kcodec" for configuration "Release"
set_property(TARGET GROK::grokj2kcodec APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(GROK::grokj2kcodec PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "GROK::grokj2k"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libgrokj2kcodec.so.20.2.5"
  IMPORTED_SONAME_RELEASE "libgrokj2kcodec.so.1"
  )

list(APPEND _cmake_import_check_targets GROK::grokj2kcodec )
list(APPEND _cmake_import_check_files_for_GROK::grokj2kcodec "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libgrokj2kcodec.so.20.2.5" )

# Import target "GROK::grk_decompress" for configuration "Release"
set_property(TARGET GROK::grk_decompress APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(GROK::grk_decompress PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/grk_decompress"
  )

list(APPEND _cmake_import_check_targets GROK::grk_decompress )
list(APPEND _cmake_import_check_files_for_GROK::grk_decompress "${_IMPORT_PREFIX}/bin/grk_decompress" )

# Import target "GROK::grk_compress" for configuration "Release"
set_property(TARGET GROK::grk_compress APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(GROK::grk_compress PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/grk_compress"
  )

list(APPEND _cmake_import_check_targets GROK::grk_compress )
list(APPEND _cmake_import_check_files_for_GROK::grk_compress "${_IMPORT_PREFIX}/bin/grk_compress" )

# Import target "GROK::grk_dump" for configuration "Release"
set_property(TARGET GROK::grk_dump APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(GROK::grk_dump PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/grk_dump"
  )

list(APPEND _cmake_import_check_targets GROK::grk_dump )
list(APPEND _cmake_import_check_files_for_GROK::grk_dump "${_IMPORT_PREFIX}/bin/grk_dump" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)

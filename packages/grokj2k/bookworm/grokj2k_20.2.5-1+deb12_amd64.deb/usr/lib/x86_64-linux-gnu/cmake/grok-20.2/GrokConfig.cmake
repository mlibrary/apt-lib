#-----------------------------------------------------------------------------
#
# GrokConfig.cmake - CMake configuration file for external projects.
#
# This file is configured by Grok and used to load Grok's settings for external projects.
#

####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was GrokConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/x86_64-linux-gnu/cmake/grok-20.2" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# === Version Information ===
set(Grok_VERSION "20.2.5")
set(Grok_VERSION_MAJOR "20")
set(Grok_VERSION_MINOR "2")
set(Grok_VERSION_PATCH "5")

# The libraries
set(Grok_LIBRARIES "GROK::grokj2k" "GROK::grokj2kcodec")

# CMake macros directory
set(Grok_CMAKE_DIR "${CMAKE_CURRENT_LIST_DIR}")

# Configuration options
set(Grok_BUILD_SHARED_LIBS "ON")

# Detect install or build tree and import targets
if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/GrokTargets.cmake")
    # Install tree
    include("${CMAKE_CURRENT_LIST_DIR}/GrokTargets.cmake")
    set(Grok_INCLUDE_DIRS "${PACKAGE_PREFIX_DIR}/include/grok-20.2")
elseif(EXISTS "${CMAKE_CURRENT_LIST_DIR}/GrokExports.cmake")
    # Build tree
    include("${CMAKE_CURRENT_LIST_DIR}/GrokExports.cmake")
    set(Grok_INCLUDE_DIRS "")
else()
    message(FATAL_ERROR
        "Could not find GrokTargets.cmake (install tree) or GrokExports.cmake (build tree). "
        "Ensure Grok is built and installed correctly.")
endif()

# Backward compatibility
set(Grok_FOUND TRUE)

include("${CMAKE_CURRENT_LIST_DIR}/GrokConfigVersion.cmake" OPTIONAL)
check_required_components(Grok)

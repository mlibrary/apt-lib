/* Grok Version */
#define GRK_VERSION_MAJOR 20
#define GRK_VERSION_MINOR 2
#define GRK_VERSION_BUILD 5

/* Feature flags */
/* #undef GRK_ENABLE_LIBCURL */
#ifdef GRK_ENABLE_LIBCURL
#define GRK_HAS_LIBCURL 1
#endif
